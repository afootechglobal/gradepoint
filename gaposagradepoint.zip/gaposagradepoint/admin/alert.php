 <div class="overlay-div"></div> 


        <div class="alert-div  animated bounceInDown" id="success-divdd">  
                <div class="alert-logo"><img src="<?php echo $website_url?>/all-images/images/tick-2.gif" alt="Hero" /></div>
                <h3>REGISTRATION SUCCESSFUL</h3>
        </div>

        <div class="alert-div  animated fadeInRight" id="success-div">  
                <div class="alert-logo"><img src="<?php echo $website_url?>/all-images/images/tick-2.gif" alt="success" /></div>
                <h3>OTP SENT</h3>
                <p>Check your email or span</p>
        </div>

        <div class="alert-div  animated fadeInRight" id="warning-div">  
                <div class="alert-logo"><img src="<?php echo $website_url?>/all-images/images/warning.gif" alt="warning" /></div>
                <h3>ERROR!</h3>
                <p>Fill the fields to continue.</p>
        </div>

        <div class="alert-div  animated bounceInDown" id="invalid-div">  
                <div class="alert-logo"><i class="fa fa-times"></i></div>
                <h3>Invalid Email or Password</h3>
                <p>please check your login details.</p>
        </div>





