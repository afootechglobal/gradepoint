  
<script src="<?php echo $website_url?>/js/aos.js"></script>

<script>
AOS.init({
  easing: 'ease-in-out-sine'
});
</script>
